go into the project and go to edit - project settings - player

there you should see company name, product name which you should set as lfairclo and RowHero


just open the file called gamelauncher.sln in vscode and then


   0. open the repo in git command line. git repo name = theo-game-launcher
my username = lfairclo
it should be logged in already

	1.	In Visual Studio: right-click the GameLauncher project → Publish → target Folder → pick an output folder.
	2.	Under settings: Deployment mode Self-contained, target runtime win-x64 → Publish.
	3.	Zip the contents of that output folder → GameLauncher.zip.
	4.	release it to the github repo
	
	gh release create launcher-v1.0.0 GameLauncher.zip --title "Launcher v1.0.0" --notes "Initial launcher build"

5. Copy the asset’s download URL and change the url in the manifest for the launcher


1.	Open the Unity project (double-click the project folder or open via Unity Hub).
	2.	Go to File → Build Settings.
	4.	Click Build.
	5.	When it asks for a folder, create a new empty folder (e.g. Desktop\GameBuild) and select it.
	6.	Wait for it to finish. you should see RowHero.exe, a RowHero_Data folder, and a couple of DLLs inside that folder.
	7.	Go into that folder, select everything inside it (not the folder itself), right-click → Send to → Compressed (zipped) folder. Name it GameBuild.zip.
	•	Important: the zip needs RowHero.exe at the top level when opened, not nested inside another folder.

Releasing it on GitHub:

gh release create game-v1.0.0 GameBuild.zip --title "Game v1.0.0" --notes "Initial release"

Then copy the download link for GameBuild.zip (right-click it on the release page → Copy Link Address) then switch that for the link in the manifest.json



go into the search in the bottom left of the windows screen and type %appdata% then hit enter. go into the games save file directory and zip the songs folder and name it GameData  

then run 
gh release upload game-v1.0.0 GameData.zip
