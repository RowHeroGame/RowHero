# Game Launcher — Setup Guide

A lightweight WPF (.NET 8) launcher that self-updates, then installs/updates
your game from a GitHub Release, driven by a single `manifest.json`.

## 1. Requirements to build

- Windows machine
- Visual Studio 2022 (Community is fine) with the **.NET desktop development**
  workload, OR the .NET 8 SDK + `dotnet build` from the command line.

This project cannot be compiled or run in this sandbox (WPF requires Windows)
— open `GameLauncher.sln` in Visual Studio on your own machine to build it.

## 2. One-time configuration

Open `GameLauncher/Config/AppConfig.cs` and edit the top block:

```csharp
public static readonly string CompanyName = "YourCompany";
public static readonly string GameName = "YourGame";
public static readonly string GameExeName = "YourGame.exe";
public static readonly string GitHubOwner = "your-github-username";
public static readonly string GitHubRepo = "your-launcher-repo";
```

`CompanyName`/`GameName` control the install paths:
- Game files → `%LocalAppData%\CompanyName\GameName\`
- Extra data zip → `%AppData%\CompanyName\GameName\`

Drop `logo.png` and `menu_bg.png` into `GameLauncher/Assets/`.

## 3. Preparing your Unity build

When you build in Unity (File → Build Settings → Build), you get an .exe
**plus** a `YourGame_Data` folder and a couple of DLLs alongside it. All of
that has to ship together — Unity splits the assets/scripts/resources out
of the exe by design. Steps:

1. Build to an empty folder, e.g. `Build/`.
2. Confirm you see `YourGame.exe`, `YourGame_Data/`, `UnityPlayer.dll` (and
   possibly `MonoBleedingEdge/` or similar depending on scripting backend)
   all sitting next to each other.
3. Zip the **contents** of that folder (not the folder itself) into
   `GameBuild.zip` — when the launcher extracts it, `YourGame.exe` should
   land directly in the install directory, not inside a subfolder.
4. If you have separate content that should live in `%AppData%` (save-independent
   config, mod support files, etc.), zip that separately as `GameData.zip`.

## 4. Hosting on GitHub Releases

1. Create a repo (can be the same one as this launcher's source, or a
   separate "distribution" repo — doesn't matter, just update `GitHubOwner`/
   `GitHubRepo` in `AppConfig.cs` to match).
2. Commit `manifest.json` (copy `manifest.example.json`, fill in real values)
   to the repo's default branch, at the root.
3. For each release, create a GitHub Release (tag it however you like, e.g.
   `game-v1.1.0`) and attach:
   - `GameBuild.zip`
   - `GameData.zip` (if you have one)
   - `GameLauncher.zip` (only when you're shipping a new *launcher* version)
4. Copy the asset download URLs (right-click the asset link on the release
   page → Copy Link) into `manifest.json`, bump the version numbers, write
   the changelog, commit.
5. That's it — every running launcher picks up the change next time it
   opens, since it always fetches the latest `manifest.json` from the repo.

GitHub Release assets are free with no bandwidth limit, capped at 2GB per
file — fine unless your build is unusually large, in which case swap the
URLs in the manifest for a Cloudflare R2 or Backblaze B2 link instead (the
launcher doesn't care where the URLs point).

## 5. Publishing the launcher itself

```
dotnet publish GameLauncher/GameLauncher.csproj -c Release -r win-x64 --self-contained true -o publish
```

Zip the contents of `publish/` as `GameLauncher.zip`, bump
`CurrentLauncherVersion` in `AppConfig.cs` for the *next* build before you
publish that one, attach today's zip to a GitHub Release, update
`manifest.json`'s `launcher.version`/`launcher.url`.

## How updating works, in short

- **Launcher self-update**: on startup, compares its own hardcoded version
  to `manifest.json → launcher.version`. If newer, downloads the zip,
  writes a small batch script that waits for the launcher to close, copies
  the new files over itself, and relaunches. This sidesteps the fact that a
  running .exe can't overwrite itself on Windows.
- **Game install/update**: compares `version.json` (written into the game's
  install folder after every successful install) against
  `manifest.json → game.version`. Button reads "Install Game" if nothing's
  installed, "Update" if a newer version is available (pressing it shows
  the changelog + new version number from the manifest before proceeding),
  or "Play" if up to date.
